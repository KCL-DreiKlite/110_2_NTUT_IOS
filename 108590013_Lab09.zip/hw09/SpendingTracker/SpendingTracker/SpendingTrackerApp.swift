//
//  SpendingTrackerApp.swift
//  SpendingTracker
//
//  Created by 郭建麟 on 2022/6/1.
//

import SwiftUI

@main
struct SpendingTrackerApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
