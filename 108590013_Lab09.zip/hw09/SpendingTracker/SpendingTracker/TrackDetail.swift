//
//  TrackDetail.swift
//  SpendingTracker
//
//  Created by 郭建麟 on 2022/6/1.
//

import Foundation

class TrackDetail {
    
    public var cost: Int
    public var type: String
    public var date: Date
    public var note: String!
    
    init(_ cost: Int, _ type: String, _ date: Date) {
        self.cost = cost
        self.type = type
        self.date = date
    }
    init(_ cost: Int, _ type: String, _ date: Date, _ note: String) {
        self.cost = cost
        self.type = type
        self.date = date
        self.note = note
    }
    
    
}
