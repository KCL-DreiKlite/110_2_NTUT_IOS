//
//  InputNewTrack.swift
//  SpendingTracker
//
//  Created by 郭建麟 on 2022/6/1.
//

import Foundation
import SwiftUI

struct ViewInputNewTrack: View {
    
    @Environment(\.presentationMode) var presentationMode: Binding<PresentationMode>
    
    @EnvironmentObject var model: Model
    
    @State var cost: String = ""
    @State var type: String = ""
    @State var date: Date = Date.now
    @State var note: String = ""
    
    @State var showAlert: Bool = false
    
    var body: some View {
        VStack {
            DatePicker("日期", selection: $date, displayedComponents: .date)
                .datePickerStyle(.wheel)
            Divider()
            HStack {
                Text("輸入金額：")
                TextField("金額", text: $cost)
                    .multilineTextAlignment(.trailing)
            }
            Divider()
            HStack {
                Text("輸入消費類型：")
                TextField("類型名稱", text: $type)
                    .multilineTextAlignment(.trailing)
            }
            Divider()
            Text("備註")
//            TextField("備註", text: $note)
//                .multilineTextAlignment(.leading)
//                .frame(maxHeight: .infinity)
//
            TextEditor(text: $note)
                .frame(maxHeight: .infinity)
            Divider()
            Button {
                if (cost == "" || type == "") {
                    showAlert = true
                    return
                }
                model.addNewTrack(Int(cost) ?? 0, type, date, note)
                presentationMode.wrappedValue.dismiss()
            } label: {
                Text("儲存")
                    .frame(maxWidth: .infinity, maxHeight: 40)
                    .font(.title3)
                    .foregroundColor(.white)
                    .background(.primary)
                    .cornerRadius(10)
            }
            .padding()
        }
        .navigationTitle("新增")
        .navigationBarTitleDisplayMode(.inline)
        .alert("\(cost == "" ? "金額不可以為空" : "")\(cost == "" && type == "" ? "\n" : "")\(type == "" ? "類型不可以為空" : "")", isPresented: $showAlert) {
            Button("好") {}
        }
    }
}
