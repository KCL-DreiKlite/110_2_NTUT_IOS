//
//  ViewTrackDetail.swift
//  SpendingTracker
//
//  Created by 郭建麟 on 2022/6/1.
//

import Foundation
import SwiftUI

struct ViewTrackDetail: View {
    
    @State var trackDetail: TrackDetail
    
    var body: some View {
        VStack {
            ScrollView {
                VStack {
                    Text("消費類型")
                        .font(.title2.bold())
                        .frame(maxWidth: .infinity, alignment: .leading)
                    Text(trackDetail.type)
                        .frame(maxWidth: .infinity, alignment: .leading)
                }
                Divider()
                VStack {
                    Text("金額")
                        .font(.title2.bold())
                        .frame(maxWidth: .infinity, alignment: .leading)
                    Text("\(trackDetail.cost)")
                        .frame(maxWidth: .infinity, alignment: .leading)
                }
                Divider()
                VStack {
                    Text("日期")
                        .font(.title2.bold())
                        .frame(maxWidth: .infinity, alignment: .leading)
                    Text(trackDetail.date.formatted(date: .long, time: .omitted))
                        .frame(maxWidth: .infinity, alignment: .leading)
                }
                Divider()
                VStack {
                    Text("備註")
                        .font(.title2.bold())
                        .frame(maxWidth: .infinity, alignment: .leading)
                    Text(trackDetail.note)
                        .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .topLeading)

                }
            }
        }
        .navigationTitle("詳細資料")
        .navigationBarTitleDisplayMode(.inline)
    }
}
