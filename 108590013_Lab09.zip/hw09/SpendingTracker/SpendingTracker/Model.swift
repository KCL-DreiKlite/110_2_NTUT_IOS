//
//  Model.swift
//  SpendingTracker
//
//  Created by 郭建麟 on 2022/6/1.
//

import Foundation


class Model: ObservableObject {
    
    @Published var tracks: Array<TrackDetail> = []
        
    public func addNewTrack(_ newTrack: TrackDetail) {
        tracks.append(newTrack)
    }
    public func addNewTrack(_ cost: Int, _ type: String, _ date: Date, _ note: String) {
        tracks.append(TrackDetail(cost, type, date, note))
    }
    
    
}
