//
//  ContentView.swift
//  SpendingTracker
//
//  Created by 郭建麟 on 2022/6/1.
//

import SwiftUI

struct ContentView: View {
    @StateObject var model = Model()
    
//    init() {
//        UISegmentedControl.appearance().selectedSegmentTintColor = .systemRed
//        UISegmentedControl.appearance().setTitleTextAttributes([.foregroundColor: UIColor.white], for: .application)
//        UISegmentedControl.appearance().setTitleTextAttributes([.foregroundColor: UIColor.systemPink], for: .normal)
//    }
    
    var body: some View {
        NavigationView {
            List(model.tracks.indices, id: \.self) { itemIndex in
                let trackDetail = model.tracks[itemIndex]
                NavigationLink {
                    ViewTrackDetail(trackDetail: trackDetail)
                } label: {
                    VStack {
                        Text(trackDetail.type)
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .font(.title2.bold())
                        Text("金額：\(trackDetail.cost), 日期：\(trackDetail.date.formatted(date: .numeric, time: .omitted)), 備註：\(trackDetail.note)")
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .font(.body)
                    }
                }
            }
            .navigationTitle("記帳本")
            .toolbar {
                NavigationLink {
                    ViewInputNewTrack()
                } label: {
                    Image(systemName: "plus")
                }
            }
        }
        .environmentObject(model)
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
