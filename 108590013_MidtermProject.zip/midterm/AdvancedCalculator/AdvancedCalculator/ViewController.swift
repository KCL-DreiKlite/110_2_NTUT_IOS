//
//  ViewController.swift
//  AdvancedCalculator
//
//  Created by 郭建麟 on 2022/4/28.
//

import UIKit

class ViewController: UIViewController {
    private let OPERATOR_SELECTED_BACKGROUND_COLOR = #colorLiteral(red: 0.9333333333, green: 0.9333333333, blue: 0.9333333333, alpha: 1)
    private let OPERATOR_SELECTED_TEXT_COLOR = #colorLiteral(red: 1, green: 0.5490196078, blue: 0.1960784314, alpha: 1)
    private let OPERATOR_UNSELECTED_BACKGROUND_COLOR = #colorLiteral(red: 1, green: 0.5490196078, blue: 0.1960784314, alpha: 1)
    private let OPERATOR_UNSELECTED_TEXT_COLOR = #colorLiteral(red: 0.02352941176, green: 0.06666666667, blue: 0.2352941176, alpha: 1)

    @IBOutlet var buttonCollection: [UIButton]!
    
    @IBOutlet weak var labelFormula: UILabel!
    @IBOutlet weak var labelInput: UILabel!
    @IBOutlet weak var buttonClear: UIButton!
    @IBOutlet weak var buttonDivide: UIButton!
    @IBOutlet weak var buttonMultiply: UIButton!
    @IBOutlet weak var buttonMinus: UIButton!
    @IBOutlet weak var buttonPlus: UIButton!
    @IBOutlet weak var buttonEqual: UIButton!
    
    private var model: Model!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        initOutlets()
    }
    private func initOutlets() {
        // Make buttons' corner rounded.
        let OFFSET: Int = 4
        let RADIUS: Int = Int((buttonCollection.first?.frame.size.height)! / 2) - OFFSET
        for button in buttonCollection {
            button.layer.cornerRadius = CGFloat(RADIUS);
        }
        
        // Declare model.
        model = Model()
        model.setNotifier(labelInputNotifier: updateLabelInput, labelFormulaNotifier: updateLabelFormula, buttonClearNotifier: updateButtonClear, operatorButtonsNotifier: updateOperatorButtons)
        
        // Initialize labels.
        updateLabelInput()
        updateLabelFormula()
        
        var number1 = Number(number: -12345.123)
        var number2 = Number(number: 0.000001)
        var result = number1 * number2
        print(result.toDouble())
        print(result.toString())
        print(Double(number1.getIntegerPart()) + number1.getFloatPart())
        
        var n1 = Number(number: 1)
        var n2 = Number(number: 2)
        print(n1.toDouble())
        print(n2.toDouble())
        n1 += n2
        print(n1.toDouble())
        print(n2.toDouble())
    }
    
    private func changeOperatorBackgroundAndTextColor(whichButton: UIButton, selectState: Bool) {
//        var textColor = whichButton.titleLabel?.textColor
//        var backgroundColor = whichButton.backgroundColor
////        whichButton.titleLabel?.textColor = backgroundColor
//        whichButton.setTitleColor(backgroundColor, for: .normal)
//        whichButton.backgroundColor = textColor
        if selectState {
            whichButton.setTitleColor(OPERATOR_SELECTED_TEXT_COLOR, for: .normal)
            whichButton.backgroundColor = OPERATOR_SELECTED_BACKGROUND_COLOR
        }
        else {
            whichButton.setTitleColor(OPERATOR_UNSELECTED_TEXT_COLOR, for: .normal)
            whichButton.backgroundColor = OPERATOR_UNSELECTED_BACKGROUND_COLOR
        }
    }
    
    @IBAction func buttonClear_Clicked(_ sender: UIButton) {
        model.clear()
    }
    @IBAction func buttonNegative_Clicked(_ sender: UIButton) {
        model.negative()
    }
    @IBAction func buttonPercent_Clicked(_ sender: UIButton) {
        model.inputPercent()
    }
    
    @IBAction func buttonNumberPad_Clicked(_ sender: UIButton) {
        let number: Int = Int((sender.titleLabel?.text)!) ?? 0
        model.inputNumber(number: number)
    }
    @IBAction func buttonDot_Clicked(_ sender: UIButton) {
        model.inputDot()
    }

    @IBAction func buttonOperator_TouchDown(_ sender: UIButton) {
//        sender.backgroundColor = OPERATOR_TOUCH_DOWN_COLOR
//        sender.backgroundColor = OPERATOR_SELECTED_BACKGROUND_COLOR
//        sender.setTitleColor(OPERATOR_SELECTED_TEXT_COLOR, for: .normal)
        
    }
    private func buttonOperator_TouchUp(_ sender: UIButton) {
//        sender.backgroundColor = OPERATOR_TOUCH_UP_COLOR
//        sender.backgroundColor = OPERATOR_UNSELECTED_BACKGROUND_COLOR
//        sender.setTitleColor(OPERATOR_UNSELECTED_TEXT_COLOR, for: .normal)
    }
    @IBAction func buttonDivide_TouchUp(_ sender: UIButton) {
        model.operateDivide()
        buttonOperator_TouchUp(sender)
    }
    @IBAction func buttonMultiply_Clicked(_ sender: UIButton) {
        model.operateMultiply()
        buttonOperator_TouchUp(sender)
    }
    @IBAction func buttonMinus_Clicked(_ sender: UIButton) {
        model.operateMinus()
        buttonOperator_TouchUp(sender)
    }
    @IBAction func buttonPlus_Clicked(_ sender: UIButton) {
        model.operatePlus()
        buttonOperator_TouchUp(sender)
    }
    
    @IBAction func buttonEqual_Clicked(_ sender: UIButton) {
        model.operateEqual()
        buttonOperator_TouchUp(sender)
    }
    
    private func updateLabelInput() {
        labelInput.text = model.getInput()
    }
    private func updateLabelFormula() {
        labelFormula.text = model.getFormula()
    }
    private func updateButtonClear() {
        if model.isClearAllMode() {
            buttonClear.setTitle("AC", for: .normal)
        }
        else {
            buttonClear.setTitle("C", for: .normal)
        }
    }
    private func updateOperatorButtons() {
        changeOperatorBackgroundAndTextColor(whichButton: buttonDivide, selectState: false)
        changeOperatorBackgroundAndTextColor(whichButton: buttonMultiply, selectState: false)
        changeOperatorBackgroundAndTextColor(whichButton: buttonMinus, selectState: false)
        changeOperatorBackgroundAndTextColor(whichButton: buttonPlus, selectState: false)
        
        switch model.getNextOperator() {
        case .PLUS:
            changeOperatorBackgroundAndTextColor(whichButton: buttonPlus, selectState: true)
            break
        case .MINUS:
            changeOperatorBackgroundAndTextColor(whichButton: buttonMinus, selectState: true)
            break
        case .MULTIPLY:
            changeOperatorBackgroundAndTextColor(whichButton: buttonMultiply, selectState: true)
            break
        case .DIVIDE:
            changeOperatorBackgroundAndTextColor(whichButton: buttonDivide, selectState: true)
            break
        default:
            break
        }
    }
}
