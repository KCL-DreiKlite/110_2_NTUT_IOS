//
//  Model.swift
//  AdvancedCalculator
//
//  Created by 郭建麟 on 2022/4/28.
//

import Foundation

class Model {
    public enum NextOperation {
        case PLUS
        case MINUS
        case MULTIPLY
        case DIVIDE
    }
    
    private var labelInputNotifier: (() -> Void)!
    private var labelFormulaNotifier: (() -> Void)!
    private var buttonClearNotifier: (() -> Void)!
    private var operatorButtonsNotifier: (() -> Void)!
    
    private var isFloatMode: Bool = false
    private var isZero: Bool = true
    private var isClearAllNext: Bool = true
    private var hasResult: Bool = false
    
    private var nextOperator: NextOperation!
    
    private var input: String = "0"
    private var formula: String = " "
//    private var inputCollection: Array<Number> = []
    private var result: Number!
    
    
    private func reset() {
        self.input = "0"
        self.formula = " "
        
        self.isZero = true
        self.isFloatMode = false
        self.isClearAllNext = true
        self.hasResult = false
        
        self.nextOperator = nil
    }
    
    public func inputNumber(number: Int) {
        var numberInChar: String = String(number)
        if hasResult {
            self.formula = " "
            hasResult = false
        }
        if self.isZero {
            self.input = numberInChar
            self.isZero = false
        }
        else {
            self.input.append(numberInChar)
        }
        self.isClearAllNext = false
        
        notifyLabelInput()
        notifyLabelFormula()
        notifyButtonClear()
    }
    public func inputDot() {
        if self.hasResult {
            self.formula = " "
            self.hasResult = false
        }
        if self.isFloatMode {
            return
        }
        if self.isZero {
            self.input = "0"
            self.isZero = false
        }
        
        self.input.append(".")
        self.isFloatMode = true
        self.isClearAllNext = false
        
        notifyLabelInput()
        notifyLabelFormula()
        notifyButtonClear()
    }
    public func clear() {
        if isClearAllNext {     // AC
            reset()
        }
        else {                  // C
            self.input = "0"
            
            self.isZero = true
            self.isFloatMode = false
            
            self.isClearAllNext = true
        }
        notifyAll()
    }
    
    public func negative() {
        if self.isZero {
            return
        }
        
        if self.input.contains("-") {   // Change to positive
            self.input.remove(at: self.input.startIndex)
        }
        else {      // Change to negative
            self.input = "-" + self.input
        }
        
        notifyLabelInput()
    }
    
    public func inputPercent() {
        var temp: Number = Number(number: self.input)
        temp /= Number(number: 100)
        self.input = temp.toString()
        
        self.isZero = false
        self.isFloatMode = true
        self.isClearAllNext = false
        
        notifyLabelInput()
        notifyButtonClear()
    }
    
    public func flushInput() {
        var input: Number = Number(number: self.input)
        var isDividedByZero: Bool = false

        if self.isZero {
            input = Number(number: 0)
        }
        
        if self.nextOperator == nil {    // Empty formula
            self.result = input
            self.formula = self.result.toString()
        }
        else {
            var operatorPresentation: String = ""
            
            switch self.nextOperator {
            case .PLUS:
                self.result += input
                operatorPresentation = "+"
                break
            case .MINUS:
                self.result -= input
                operatorPresentation = "-"
                break
            case .MULTIPLY:
                self.result *= input
                operatorPresentation = "*"
                break
            case .DIVIDE:
                if input == Number(number: 0) {
                    isDividedByZero = true
                }
                else {
                    self.result /= input                    
                }
                operatorPresentation = "/"
                break
            default:
                self.result = input
                break
            }
            self.formula.append(" \(operatorPresentation) \(input.toString())")
        }
        
        if isDividedByZero {
            self.input = "Undefined"
        }
        else if isZero {
            self.input = "0"
        }
        else {
            self.input = self.result.toString()
        }
        self.isZero = true
        self.isFloatMode = false
    }
    
    public func operatePlus() {
//        let input: Number = Number(number: self.input)
        flushInput()
        self.nextOperator = NextOperation.PLUS
        
        notifyLabelFormula()
        notifyLabelInput()
        notiftOperatorButtons()
    }
    public func operateMinus() {
        flushInput()
        self.nextOperator = NextOperation.MINUS
        
        notifyLabelFormula()
        notifyLabelInput()
        notiftOperatorButtons()
    }
    public func operateMultiply() {
        flushInput()
        self.nextOperator = NextOperation.MULTIPLY
        
        notifyLabelFormula()
        notifyLabelInput()
        notiftOperatorButtons()
    }
    public func operateDivide() {
        flushInput()
        self.nextOperator = NextOperation.DIVIDE
        
        notifyLabelFormula()
        notifyLabelInput()
        notiftOperatorButtons()
    }
    public func operateEqual() {
        flushInput()
        self.nextOperator = nil
        self.isClearAllNext = true
        self.hasResult = true
        
        notifyAll()
    }
    
    private func notifyAll() {
        notifyLabelInput()
        notifyLabelFormula()
        notifyButtonClear()
        notiftOperatorButtons()
    }
    private func notifyLabelInput() {
        if labelInputNotifier != nil {
            labelInputNotifier()
        }
    }
    private func notifyLabelFormula() {
        if labelFormulaNotifier != nil {
            labelFormulaNotifier()
        }
    }
    private func notifyButtonClear() {
        if buttonClearNotifier != nil {
            buttonClearNotifier()
        }
    }
    private func notiftOperatorButtons() {
        if operatorButtonsNotifier != nil {
            operatorButtonsNotifier()
        }
    }
    
    public func setNotifier(labelInputNotifier: @escaping () -> Void, labelFormulaNotifier: @escaping () -> Void, buttonClearNotifier: @escaping () -> Void, operatorButtonsNotifier: @escaping () -> Void) {
        self.labelInputNotifier = labelInputNotifier
        self.labelFormulaNotifier = labelFormulaNotifier
        self.buttonClearNotifier = buttonClearNotifier
        self.operatorButtonsNotifier = operatorButtonsNotifier
    }
    
    
//    public func getInputToString() -> String {
//        if (inputDecimalPart == nil) {
//            return "0"
//        }
//        if (!isFloatMode) {
//            return "\(inputDecimalPart)"
//        }
//        return "\(inputDecimalPart).\(inputFloatPart)"
//    }
    public func getInput() -> String {
        return self.input
    }
    public func getFormula() -> String {
        return self.formula
    }
    public func getNextOperator() -> NextOperation! {
        return self.nextOperator
    }
    public func isClearAllMode() -> Bool {
        return self.isClearAllNext
    }
    
}
