//
//  Number.swift
//  AdvancedCalculator
//
//  Created by 郭建麟 on 2022/4/29.
//

import Foundation


class Number {
    static prefix func -(value: Number) -> Number {
//        let negationValue: Number = Number(number: value)
//        negationValue.isNeg = !negationValue.isNeg
//        return negationValue
        return Number(number: -value.toDouble())
    }
    
    static func +(left: Number, right: Number) -> Number {
        return Number(number: left.toDouble() + right.toDouble())
    }
    static func -(left: Number, right: Number) -> Number {
        return Number(number: left.toDouble() - right.toDouble())
    }
    static func *(left: Number, right: Number) -> Number {
        return Number(number: left.toDouble() * right.toDouble())
    }
    static func /(left: Number, right: Number) -> Number {
        return Number(number: left.toDouble() / right.toDouble())
    }
    
    static func +=(target: inout Number, value: Number) {
        target = target + value
    }
    static func -=(target: inout Number, value: Number) {
        target = target - value
    }
    static func *=(target: inout Number, value: Number) {
        target = target * value
    }
    static func /=(target: inout Number, value: Number) {
        target = target / value
    }
    
    static func ==(left: Number, right: Number) -> Bool {
        return left.toDouble() == right.toDouble()
    }
//    private var isNeg: Bool
//    private var decimalPart: Int
//    private var floatPart: Int
    private var value: Double
    
    init() {
//        self.isNeg = false
//        self.decimalPart = 0
//        self.floatPart = 0
        self.value = 0
    }
    init(number: Number) {
//        self.isNeg = number.isNeg
//        self.decimalPart = number.decimalPart
//        self.floatPart = number.floatPart
        self.value = number.value
    }
    init(number: Int) {
//        self.isNeg = number < 0
//        self.decimalPart = abs(number)
//        self.floatPart = 0
        self.value = Double(number)
        
    }
    init(number: Double) {
//        self.isNeg = number < 0
//
//        let numberInString: String = String(number)
//        let splittedString = numberInString.split(separator: ".")
//        if splittedString.count == 1 {
//            self.decimalPart = abs(Int(number))
//            self.floatPart = 0
//        }
//        else {
//            self.decimalPart = abs(Int(splittedString[0]) ?? 0)
//            self.floatPart = abs(Int(splittedString[1]) ?? 0)
//        }
        self.value = number
    }
//    init(decimalPart: Int, floatPart: Int) {
//        self.isNeg = decimalPart * floatPart < 0
//        self.decimalPart = decimalPart
//        self.floatPart = floatPart
//    }
    init(number: String) {
        self.value = Double(number) ?? 0
    }
    
//    public func appendNumber(digit: Int, isFloat: Bool) {
//        var processedDigit: Double = Double(abs(digit))
//        if isNegative() {
//            processedDigit *= -1
//        }
//
//        if isFloat {
//            var digitCount: Double = floor(log10(getFloatPart())) - 1
//            if getFloatPart() == 0 {
//                digitCount = -1
//            }
//            let appendTo: Double = pow(10, digitCount)
//            let finalAppended: Double = appendTo * processedDigit
//            self.value += finalAppended
//        }
//        else if isInteger() {
//            self.value = self.value * 10 + processedDigit
//        }
//        else {
//            var integerPart: Double = Double(getSignedIntegerPart())
//            var floatPart: Double = getSignedFloatPart()
//            integerPart = integerPart * 10 + processedDigit
//
//            self.value = integerPart + floatPart
//        }
//    }
    
    public func getIntegerPart() -> Int {
        return abs(Int(self.value))
    }
    public func getSignedIntegerPart() -> Int {
        if isNegative() {
            return -getIntegerPart()
        }
        return getIntegerPart()
    }
    public func getFloatPart() -> Double {
//        if floatPart == 0 {
//            return 0
//        }
//        let digitCount: Int = Int(log10(Double(self.floatPart))) + 1
//        let divisor: Double = pow(10, Double(digitCount))
//        return Double(floatPart) / divisor
        return abs(self.value) - Double(getIntegerPart())
    }
    public func getSignedFloatPart() -> Double {
        if isNegative() {
            return -getFloatPart()
        }
        return getFloatPart()
    }
    
    public func isNegative() -> Bool {
        return self.value < 0
    }
    public func isInteger() -> Bool {
        return self.value == Double(Int(self.value))
    }
    public func isFloat() -> Bool {
        return !isInteger()
    }

    public func toDouble() -> Double {
//        var result: Double = Double(getIntegerValue()) + getFloatValue()
//        if self.isNeg {
//            return -result
//        }
//        return result
        return self.value
    }
    public func toString() -> String {
//        if self.floatPart == 0 {
//            return (self.isNeg ? "-" : "") + "\(self.decimalPart)"
//        }
//
//        return (self.isNeg ? "-" : "") +  "\(self.decimalPart).\(self.floatPart)"
        if isInteger() {
            return "\(Int(self.value))"
        }
        return "\(self.value)"
    }
}
