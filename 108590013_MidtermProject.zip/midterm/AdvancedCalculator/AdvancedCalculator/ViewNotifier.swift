//
//  ViewNotifier.swift
//  AdvancedCalculator
//
//  Created by 郭建麟 on 2022/4/28.
//

import Foundation

protocol ViewNotifier {
    func notify()
}
