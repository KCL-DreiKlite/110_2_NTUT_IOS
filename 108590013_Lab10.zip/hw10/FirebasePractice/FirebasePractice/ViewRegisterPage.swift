//
//  ViewRegisterPage.swift
//  FirebasePractice
//
//  Created by 郭建麟 on 2022/6/8.
//

import Foundation
import FirebaseAuth
import SwiftUI

struct ViewRegisterPage: View {
    
    let textfieldMaxHeight = 30.0
    
    @State var name: String = ""
    @State var email: String = ""
    @State var password: String = ""
    @State var comfirmPassword: String = ""
    
    @State var showAlert: Bool = false
    @State var alertMessage: String = ""
    
    @Binding var isLoginPage: Bool
    
    var body: some View {
        VStack {
            TextField("Name", text: $name)
                .textInputAutocapitalization(.never)
                .frame(maxWidth: .infinity, maxHeight: textfieldMaxHeight)
                .padding()
                .background(Color.white)
                .cornerRadius(15)

            TextField("Email Address", text: $email)
                .textInputAutocapitalization(.never)
                .frame(maxWidth: .infinity, maxHeight: textfieldMaxHeight)
                .padding()
                .background(Color.white)
                .cornerRadius(15)

            SecureField("Password", text: $password)
                .textInputAutocapitalization(.never)
                .frame(maxWidth: .infinity, maxHeight: textfieldMaxHeight)
                .padding()
                .background(Color.white)
                .cornerRadius(15)

            SecureField("Comfirm Password", text: $comfirmPassword)
                .textInputAutocapitalization(.never)
                .frame(maxWidth: .infinity, maxHeight: textfieldMaxHeight)
                .padding()
                .background(Color.white)
                .cornerRadius(15)

            Button {
                // Register button pressed.
                if self.name == "" {
                    alertMessage = "Username cannot be empty"
                    showAlert = true
                    return
                }
                if self.email == "" {
                    alertMessage = "Email cannot be empty"
                    showAlert = true
                    return
                }
                if self.password == "" {
                    alertMessage = "Password cannot be empty"
                    showAlert = true
                    return
                }
                if password != comfirmPassword {
                    alertMessage = "Password does not match. Please try again"
                    password = ""
                    comfirmPassword = ""
                    showAlert = true
                    return
                }
                
                Auth.auth().createUser(withEmail: email, password: password) {result, error in
                    guard let user = result?.user, error == nil else {
                        alertMessage = "Something goes wrong while registering"
                        showAlert = true
                        return
                    }
                    if let currentUser = Auth.auth().currentUser?.createProfileChangeRequest() {
                        currentUser.displayName = name
                        currentUser.commitChanges()
                    }
                    alertMessage = "Register successed"
                    showAlert = true
                }
            } label: {
                Text("REGISTER")
                    .frame(maxWidth: .infinity, maxHeight: textfieldMaxHeight)
                    .padding()
                    .background(Color.yellow)
                    .foregroundColor(Color.white)
                    .font(.title2.bold())
                    .cornerRadius(15)

            }
            .alert(alertMessage, isPresented: $showAlert, actions: {})
            HStack {
                Text("Already registered?")
                Button {
                    isLoginPage = true
                } label: {
                    Text("Login")
                        .foregroundColor(Color.white)
                }

            }
        }
        .padding(30)
        .background(Color.orange)
        .cornerRadius(15)

    }
}
