//
//  ContentView.swift
//  FirebasePractice
//
//  Created by 郭建麟 on 2022/6/7.
//

import SwiftUI
import FirebaseAuth
import FirebaseCore



struct ContentView: View {
        
    @State var showAlert = false
    @State var isLoginPage = true
    
    @State var hasLogined: Bool
    
    @State var currentUsername: String!
    @State var currentUserEmail: String!
    
    init() {
//        FirebaseApp.configure()
        if let user = Auth.auth().currentUser {
            _hasLogined = State(initialValue: true)
            _currentUsername = State(initialValue: user.displayName)
            _currentUserEmail = State(initialValue: user.email)
//            _email = State(initialValue: user.email)
//            _uid = State(initialValue: user.uid)
//            print("login, Email:\(user.email ?? "")\tUID:\(user.displayName ?? "")")
        }
        else {
            _hasLogined = State(initialValue: false)
            print("not login")
        }
    }
    
    var body: some View {
        VStack {
            if isLoginPage {
                ViewLoginPage(isLoginPage: $isLoginPage, currentUsername: $currentUsername, currentUserEmail: $currentUserEmail)
                    .padding()
                if currentUserEmail != nil {
                    Text("You're now login as")
                    Text("Name: \(currentUsername ?? "*username not provided*")")
                    Text("Email: \(currentUserEmail)")
                }
            }
            else {
                ViewRegisterPage(isLoginPage: $isLoginPage)
                    .padding()
            }
//            Button {
//                Auth.auth().signIn(withEmail: "ohmygod123456@ntut.edu.org", password: "123456") {result, error in
//                    guard error == nil else {
//                        print("ERROR!")
//                        print(error?.localizedDescription)
//                        return
//                    }
//                    print("success")
//
//                    let user = result?.user
//                    email = user?.email
//                    uid = user?.uid
//                }
//            } label: {
//                Text("Click me to login!")
//            }
//
//            Text("Email:\(email ?? "")\tUID:\(uid ?? "")")
//            Text("hi")
//            ViewRegisterPage()
//            ViewLoginPage()
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .background(Color.mint)
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
