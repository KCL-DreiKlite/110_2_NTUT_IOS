//
//  ViewLoginPage.swift
//  FirebasePractice
//
//  Created by 郭建麟 on 2022/6/8.
//

import Foundation
import SwiftUI
import FirebaseAuth


struct ViewLoginPage: View {
//    @State var name: String = ""
    @State var password: String = ""
    @State var email: String = ""
    
    @State var showAlert: Bool = false
    @State var alertMessage: String = ""
    
    @Binding var isLoginPage: Bool
    
    @Binding var currentUsername: String!
    @Binding var currentUserEmail: String!
    
    var body: some View {
        VStack {
//            TextField("Name", text: $name)
//                .frame(maxWidth: .infinity, maxHeight: 30)
//                .padding()
//                .background(Color.white)
            TextField("Email Address", text: $email)
                .textInputAutocapitalization(.never)
                .frame(maxWidth: .infinity, maxHeight: 30)
                .padding()
                .background(Color.white)
                .cornerRadius(15)
            SecureField("Password", text: $password)
                .textInputAutocapitalization(.never)
                .frame(maxWidth: .infinity, maxHeight: 30)
                .padding()
                .background(Color.white)
                .cornerRadius(15)
            Button {
                // Login button pressed.
                if self.email == "" {
                    alertMessage = "Email cannot be empty"
                    showAlert = true
                    return
                }
                if self.password == "" {
                    alertMessage = "Password cannot be empty"
                    showAlert = true
                    return
                }
                
                Auth.auth().signIn(withEmail: self.email, password: self.password) {result, error in
                    guard error == nil else {
                        alertMessage = "Something goes wrong"
                        showAlert = true
                        return
                    }
                    
                    if let user = result?.user {
                        currentUsername = user.displayName
                        currentUserEmail = user.email
                        alertMessage = "Login successed"
                        print("hello")
                    }
                    else {
                        currentUsername = nil
                        currentUserEmail = nil
                        alertMessage = "Login failed"
                        print("fuckyou")
                    }
                    
                    showAlert = true
                }
            } label: {
                Text("LOG IN")
                    .frame(maxWidth: .infinity, maxHeight: 30)
                    .padding()
                    .background(Color.yellow)
                    .foregroundColor(Color.white)
                    .font(.title2.bold())
                    .cornerRadius(15)

            }
            .alert(alertMessage, isPresented: $showAlert, actions: {})
            HStack {
                Text("New here?")
                Button {
                    isLoginPage = false
                } label: {
                    Text("Register")
                        .foregroundColor(Color.white)
                }

            }
        }
        .padding(30)
        .background(Color.orange)
        .cornerRadius(15)

    }
}
