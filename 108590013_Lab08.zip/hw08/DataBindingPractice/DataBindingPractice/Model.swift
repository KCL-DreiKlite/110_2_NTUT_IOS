//
//  Model.swift
//  DataBindingPractice
//
//  Created by 郭建麟 on 2022/5/24.
//

import Foundation

class Model: ObservableObject {
    
    @Published var name: String
    @Published var birthday: Date
    @Published var nation: Nation
    @Published var politicalSpectrum: Double
    @Published var isJew: Bool
    @Published var loyaltyPoint: Int
    
    init() {
        name = ""
        birthday = DateComponents(calendar: .current, year: 1939, month: 1, day: 1).date!
        nation = Nation.NATIONS.first!
        politicalSpectrum = 0
        isJew = false
        loyaltyPoint = 0
    }
    
    func getPoliticalDescription() -> String {
        if politicalSpectrum < -8 {
            return "極左派"
        }
        if politicalSpectrum < -5 {
            return "左派"
        }
        if politicalSpectrum < -1 {
            return "中間偏左"
        }
        if politicalSpectrum < 1 {
            return "中立"
        }
        if politicalSpectrum < 5 {
            return "中間偏右"
        }
        if politicalSpectrum < 8 {
            return "右派"
        }
        return "極右派"
    }
}
