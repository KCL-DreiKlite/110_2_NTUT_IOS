//
//  AreYouJews.swift
//  DataBindingPractice
//
//  Created by 郭建麟 on 2022/5/24.
//

import Foundation
import SwiftUI

struct AreYouJews: View {
    @StateObject var model: Model
    
    var body: some View {
        HStack {
            Toggle("你是猶太人嗎？", isOn: $model.isJew)
        }
    }
}
