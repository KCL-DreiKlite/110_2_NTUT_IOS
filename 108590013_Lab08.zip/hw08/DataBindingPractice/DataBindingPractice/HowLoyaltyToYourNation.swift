//
//  HowLoyaltyToYourNation.swift
//  DataBindingPractice
//
//  Created by 郭建麟 on 2022/5/24.
//

import Foundation
import SwiftUI

struct HowLoyaltyToYourNation: View {
    @StateObject var model: Model
    
    var body: some View {
        HStack {
            Text("你有多忠於自己的國家？")
            Stepper("\(model.loyaltyPoint)", value: $model.loyaltyPoint)
        }
    }
}
