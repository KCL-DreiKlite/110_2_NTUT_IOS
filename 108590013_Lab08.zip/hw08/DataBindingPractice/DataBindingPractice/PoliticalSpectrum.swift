//
//  PoliticalSpectrum.swift
//  DataBindingPractice
//
//  Created by 郭建麟 on 2022/5/24.
//

import Foundation
import SwiftUI

struct PoliticalSpectrum: View {
    @StateObject var model: Model
        
    var body: some View {
        HStack {
            Text("選擇你的政治傾向：")
            VStack {
                Slider(value: $model.politicalSpectrum, in: -10...10, step: 0.5)
                    .accentColor(.red)
                Text("\(model.getPoliticalDescription())(\(model.politicalSpectrum, specifier: "%.1f"))")
                    .font(.callout)
            }
        }
    }
}
