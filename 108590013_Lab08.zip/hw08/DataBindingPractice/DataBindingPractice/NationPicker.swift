//
//  NationPicker.swift
//  DataBindingPractice
//
//  Created by 郭建麟 on 2022/5/22.
//

import Foundation
import SwiftUI

struct NationPicker: View {
    @StateObject var model: Model
    
    var body: some View {
        HStack {
            Text("選擇你的國籍：")
            Spacer()
            Picker(selection: $model.nation) {
                ForEach(Nation.NATIONS, id: \.name) { item in
                    HStack {
                        Text(item.name)
                    }
                    .tag(item)
                }
            } label: {
                Text("nation_picker")
            }
            Image(model.nation.imageName)
                .resizable()
                .scaledToFit()
                .frame(maxHeight: 16)
        }
    }
}

struct Nation: Hashable {
    static let NATIONS: Array<Nation> = [
        Nation(name: "德意志第三帝國", imageName: "nazi"),
        Nation(name: "蘇維埃社會主義共和國聯邦", imageName: "ussr"),
        Nation(name: "聯合王國", imageName: "uk"),
        Nation(name: "義大利王國", imageName: "italy"),
        Nation(name: "法蘭西第三共和國", imageName: "france"),
        Nation(name: "波蘭第二共和國", imageName: "poland")
    ]
    var name: String
    var imageName: String
    
}
