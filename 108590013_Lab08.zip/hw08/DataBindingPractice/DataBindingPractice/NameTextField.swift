//
//  NameTextField.swift
//  DataBindingPractice
//
//  Created by 郭建麟 on 2022/5/24.
//

import Foundation
import SwiftUI

struct NameTextField: View {
    @StateObject var model: Model
    
    var body: some View {
        TextField("輸入你的名字", text: $model.name)
    }
}
