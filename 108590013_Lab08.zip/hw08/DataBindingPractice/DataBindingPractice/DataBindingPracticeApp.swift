//
//  DataBindingPracticeApp.swift
//  DataBindingPractice
//
//  Created by 郭建麟 on 2022/5/22.
//

import SwiftUI

@main
struct DataBindingPracticeApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
