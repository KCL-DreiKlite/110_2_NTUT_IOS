//
//  BirthdayPicker.swift
//  DataBindingPractice
//
//  Created by 郭建麟 on 2022/5/24.
//

import Foundation
import SwiftUI

struct BirthdayPicker: View {
//    @State var birthday: Date = DateComponents(calendar: .current, year: 1939, month: 4, day: 1).date!
    @StateObject var model: Model
    
    
    var body: some View {
        VStack {
            DatePicker("選擇你的生日：", selection: $model.birthday, displayedComponents: .date)
        }
    }
}
