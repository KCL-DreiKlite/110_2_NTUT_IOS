//
//  ContentView.swift
//  DataBindingPractice
//
//  Created by 郭建麟 on 2022/5/22.
//

import SwiftUI

struct ContentView: View {

    @StateObject var model = Model()
    
    @State var showAlert: Bool = false
    
    var body: some View {
        VStack {
            Text("二戰前夕歐洲人模擬器")
                .font(.title.bold())
            Image("europe_1939")
                .resizable()
                .scaledToFit()
                .frame(maxHeight: 250)
                .cornerRadius(50)
            
            
            NameTextField(model: model)
            BirthdayPicker(model: model)
            NationPicker(model: model)
            PoliticalSpectrum(model: model)
            AreYouJews(model: model)
            HowLoyaltyToYourNation(model: model)
            
            Button {
                showAlert = true
            } label: {
                Text("創建角色！")
                    .frame(maxWidth: .infinity, maxHeight: 50)
                    .font(.title2)
                    .background(.pink)
                    .foregroundColor(.white)
                    .cornerRadius(10)
            }
            .alert("你的名字是：\(model.name)\n你的生日是：\(model.birthday.formatted())\n你的國籍是：\(model.nation.name)\n你的政治傾向：\(model.getPoliticalDescription())\n你\(model.isJew ? "是" : "不是")猶太人\n你的忠誠點數為：\(model.loyaltyPoint)", isPresented: $showAlert) {
                Button("褲欸") {}
            }

            
        }
        .padding()
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
