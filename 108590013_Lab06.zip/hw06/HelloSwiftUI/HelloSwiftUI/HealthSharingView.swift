//
//  HealthSharingView.swift
//  HelloSwiftUI
//
//  Created by 郭建麟 on 2022/5/11.
//

import Foundation
import SwiftUI


struct HealthSharingView: View {
    var body: some View {
        VStack {
            Image("icon_people")
                .resizable()
                .scaledToFit()
                .frame(maxWidth: 100, maxHeight: 100)
            Text("Health Sharing")
                .font(.largeTitle.bold())
                .padding()
            HStack {
                Spacer()
                Image("icon_check")
                    .resizable()
                    .scaledToFit()
                    .frame(maxWidth: 80, maxHeight: 80)
                VStack {
                    Text("You're in Control")
                        .font(.title3.bold())
                        .frame(maxWidth: .infinity, alignment: .leading)
                    Text("Keep friends and family up to date on how you're doing by securely sharing your Health data.")
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .foregroundColor(Color.gray)
                }
                Spacer()
            }
            HStack {
                Spacer()
                Image("icon_notification")
                    .resizable()
                    .scaledToFit()
                    .frame(maxWidth: 80, maxHeight: 80)
                VStack {
                    Text("Dashboard and Notification")
                        .font(.title3.bold())
                        .frame(maxWidth: .infinity, alignment: .leading)
                    Text("Data you share will appear in their Health app. They can also get notifications if there's an update.")
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .foregroundColor(Color.gray)
                }
                Spacer()
            }
            HStack {
                Spacer()
                Image("icon_lock")
                    .resizable()
                    .scaledToFit()
                    .frame(maxWidth: 80, maxHeight: 80)
                VStack {
                    Text("Private and Secure")
                        .font(.title3.bold())
                        .frame(maxWidth: .infinity, alignment: .leading)
                    Text("Only a summary of each topic is shared, not the details. The information is encrypted and you can stop sharing at any time.")
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .foregroundColor(Color.gray)
                }
                Spacer()
            }
            Button(action: {
                print("i love you")
            }, label: {
                Spacer(minLength: 60)
                Text("Share with Someone")
                    .scaledToFit()
                    .frame(maxWidth: .infinity, maxHeight: 35)
                    .font(.title3.bold())
                    .background(Color.blue)
                    .foregroundColor(Color.white)
                    .cornerRadius(20)
                Spacer(minLength: 60)
            })
        }
    }
}

struct Preview: PreviewProvider {
    static var previews: some View {
        HealthSharingView()
    }
}
