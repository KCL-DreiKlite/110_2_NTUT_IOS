//
//  AppleMusicJoinView.swift
//  HelloSwiftUI
//
//  Created by 郭建麟 on 2022/5/11.
//

import Foundation
import SwiftUI

struct AppleMusicJoinView: View {
    var body: some View {
        VStack {
            Image("apple_music_background")
                .resizable()
                .scaledToFit()
            VStack {
                HStack {
                    Image("apple_logo")
                        .resizable()
                        .scaledToFit()
                        .frame(width: 38, height: 38, alignment: .center)
                    Text("News+")
                        .font(.largeTitle)
                        .bold()
                }
                Text("Great news!")
                    .font(.title)
                    .bold()
                Text("Audio stories are here.")
                    .font(.title)
                    .bold()
                    .foregroundColor(Color.pink)
                Text("Listen only in Apple News+.")
                    .font(.title)
                    .bold()
                Button(action: {
                    print("oof, this feature is not implemented yet")
                }, label: {
                    HStack {
                        Spacer(minLength: 5)
                        Text("Get Started")
                            .frame(maxWidth: .infinity, maxHeight: 50, alignment: .center)
                            .background(Color(red: 233/255, green: 71/255, blue: 93/255))
                            .foregroundColor(Color.white)
                            .font(.title2.bold())
                            .cornerRadius(15)
                        Spacer(minLength: 5)
                    }
                })
                    
                Text("Plan auto-renews for $9.99/month until cancled.")
                    .font(.caption)
                    .foregroundColor(Color.gray)
                
                Spacer()
            }
        }
    }
}
