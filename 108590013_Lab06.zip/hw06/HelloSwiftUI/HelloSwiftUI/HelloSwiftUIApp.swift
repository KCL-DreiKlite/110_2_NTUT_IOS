//
//  HelloSwiftUIApp.swift
//  HelloSwiftUI
//
//  Created by 郭建麟 on 2022/5/11.
//

import SwiftUI

@main
struct HelloSwiftUIApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
