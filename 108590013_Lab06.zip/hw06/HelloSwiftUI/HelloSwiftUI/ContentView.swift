//
//  ContentView.swift
//  HelloSwiftUI
//
//  Created by 郭建麟 on 2022/5/11.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
//        AppleMusicJoinView()
        HealthSharingView()
    }
    
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
