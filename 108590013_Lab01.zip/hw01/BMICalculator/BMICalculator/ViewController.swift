//
//  ViewController.swift
//  BMICalculator
//
//  Created by 郭建麟 on 2022/3/2.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var txtfieldHeight: UITextField!
    @IBOutlet weak var txtfieldWeight: UITextField!
    @IBOutlet weak var sgmntctrlGender: UISegmentedControl!
    @IBOutlet weak var txtfieldBMI: UITextField!
    @IBOutlet weak var lblResult: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


    @IBAction func btnCalculateActionEvent(_ sender: Any) {
        if txtfieldHeight.text == "" || txtfieldWeight.text == "" {
            return
        }
        
        let height: Double? = Double(txtfieldHeight.text!)! / 100
        let weight: Double? = Double(txtfieldWeight.text!)

        let BMI: Double = weight! / (height! * height!)
        
        txtfieldBMI.text = String(BMI)
        
        let result: String?
        
        if BMI <= 18.5 {
             result = "Underweight"
        }
        else if BMI <= 24.9 {
            result = "Healthy weight"
        }
        else if BMI <= 29.9 {
            if sgmntctrlGender.selectedSegmentIndex == 1 {
                result = "it's a secret"
            }
            else {
                result = "Overweight"
            }
        }
        else {
            if sgmntctrlGender.selectedSegmentIndex == 1 {
                result = "it's a secret"
            }
            else {
                result = "Obesity"
            }
        }
        
        lblResult.text = "Weight Status: " + result!
        
    }
    
}


