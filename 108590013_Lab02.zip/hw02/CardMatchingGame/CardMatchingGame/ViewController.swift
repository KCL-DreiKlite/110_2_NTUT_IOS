//
//  ViewController.swift
//  CardMatchingGame
//
//  Created by 郭建麟 on 2022/3/9.
//

import UIKit

class ViewController: UIViewController {

    let CARD_1_TITLE: String = "㊙️"
    let CARD_2_TITLE: String = "💯"
    
    let FLIPPED_COLOR = #colorLiteral(red: 0.1058823529, green: 0.1019607843, blue: 0.09019607843, alpha: 1)
    let UNFLIP_COLOR = #colorLiteral(red: 0.8941176471, green: 0.3450980392, blue: 0.1490196078, alpha: 1)
    
    let EACH_CARD_TITLE: [String] = ["🌐", "⚜️", "㊙️", "⚜️", "㊙️", "🌐", "🇹🇼", "🇹🇼"]

    var checkedCardTitle: [String] = Array<String>()
    
    var previousCardIndex: Int?
    var isFlippedTwoCard: Bool = false

    @IBOutlet weak var lblFlipCount: UILabel!
    

    @IBOutlet var btnCards: [UIButton]!
    
    var flipCount: Int = 0 {
        didSet {
            lblFlipCount.text = "Flips: \(flipCount)"
        }
    }

    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        lblFlipCount.layer.cornerRadius = 20

        for index in 0...7 {
            flipCard(flippedCardIndex: index, isCover: true)
        }
    }
    
//    func updateFlipCountLabel() {
//        flipCount += 1
//        lblFlipCount.text = "Flips: \(flipCount)"
//    }
    
    func cardClicked(button: UIButton, whichCard: Int) {
        if whichCard == -1 {
            return
        }
        
        if checkedCardTitle.contains(EACH_CARD_TITLE[whichCard]) {
            return
        }
        
        if isFlippedTwoCard {
            for index in 0...7 {
                if checkedCardTitle.contains(EACH_CARD_TITLE[index]) {
                    continue
                }
                flipCard(flippedCardIndex: index, isCover: true)
            }
            
            isFlippedTwoCard = false
            return
        }
        
        flipCount += 1
        
        if flipCount % 2 == 0 { // Has fliped 2 cards
            flipCard(flippedCardIndex: whichCard, isCover: false)
            if EACH_CARD_TITLE[previousCardIndex!] == EACH_CARD_TITLE[whichCard] {
                checkedCardTitle.append(EACH_CARD_TITLE[whichCard])
            }
            else {
                isFlippedTwoCard = true
            }
        }
        else {      // Filped 1 card only
            previousCardIndex = whichCard
            flipCard(flippedCardIndex: whichCard, isCover: false)
        }
        
//        if button.currentTitle == title {
//            button.setTitle("", for: UIControl.State.normal)
//            button.backgroundColor = FLIPED_COLOR
//        }
//        else {
//            button.setTitle(title, for: UIControl.State.normal)
//            button.backgroundColor = UNFLIP_COLOR
//        }
        
        //updateFlipCountLabel()

    }
    
    func flipCard(flippedCardIndex: Int, isCover: Bool) {
        if flippedCardIndex == -1 {
            return
        }
        
        let flippedCard: UIButton = btnCards[flippedCardIndex]
        let cardTitle: String = EACH_CARD_TITLE[flippedCardIndex]
        
        if !isCover {
            flippedCard.setTitle(cardTitle, for: UIControl.State.normal)
            flippedCard.backgroundColor = UNFLIP_COLOR

        }
        else {
            flippedCard.setTitle("", for: UIControl.State.normal)
            flippedCard.backgroundColor = FLIPPED_COLOR
        }
    }

    func getCardIndex(button: UIButton) -> Int {
        for index in 0...7 {
            if btnCards[index] == button {
                return index
            }
        }
        return -1
    }
    
    @IBAction func btnCardClicled(_ sender: UIButton) {
        cardClicked(button: sender, whichCard: getCardIndex(button: sender))
    }
}

