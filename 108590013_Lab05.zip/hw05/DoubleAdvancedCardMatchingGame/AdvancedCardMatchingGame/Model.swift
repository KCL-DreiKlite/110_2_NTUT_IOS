//
//  Model.swift
//  AdvancedCardMatchingGame
//
//  Created by 郭建麟 on 2022/3/30.
//

import Foundation

class Model {
    
    private static let DEFAULT_THEME: Array<String> = GameTheme.THEME_NATIONAL_FLAG
    
    private var currentTheme: Array<String>?
    
    private var eachCardContent: Array<String>?
    private var eachCardIsFlipped: Array<Bool>?
    private var eachCardIsChecked: Array<Bool>?
    
    private var previousFlippedCardIndex: Int?
    
    private var flipCount: Int = 0
    private var score: Int = 0
    
    public init() {
        
        currentTheme = Model.DEFAULT_THEME
    }
    
    private func shuffle() {
        eachCardContent = Array<String>(repeating: "", count: 16)
        eachCardIsFlipped = Array<Bool>(repeating: false, count: 16)
        eachCardIsChecked = Array<Bool>(repeating: false, count: 16)
        for i in 0...15 {
            var curEmoji: String = currentTheme![i / 2]
            var rnd: Int = Int.random(in: 0...15)
            while eachCardContent![rnd] != "" {
                rnd = Int.random(in: 0...15)
            }
            eachCardContent![rnd] = curEmoji
        }
    }
    
    private func checkWin() -> Bool {
        for i in 0...15 {
            if !eachCardIsChecked![i] {
                return false
            }
        }
        return true
    }
    
    public func cardClicked(cardIndex: Int) {
        if checkWin() || eachCardIsChecked![cardIndex] {
            return
        }
        if previousFlippedCardIndex != nil && flipCount % 2 == 0 {
            // Un flip all card
            previousFlippedCardIndex = nil
            for i in 0...15 {
                if !eachCardIsChecked![i] {
                    eachCardIsFlipped![i] = false
                }
            }
            return
        }
        
        
        if previousFlippedCardIndex == cardIndex {
            // Flip card back
            eachCardIsFlipped![cardIndex] = false
            previousFlippedCardIndex = nil
        }
        else if previousFlippedCardIndex == nil {
            // First click
            eachCardIsFlipped![cardIndex] = true
            previousFlippedCardIndex = cardIndex
        }
        else {
            // Second click, check pair
            eachCardIsFlipped![cardIndex] = true
            let previousCardContent = eachCardContent![previousFlippedCardIndex!]
            let currentCardContent = eachCardContent![cardIndex]
            
            if previousCardContent == currentCardContent {  // Matched
                eachCardIsChecked![previousFlippedCardIndex!] = true
                eachCardIsChecked![cardIndex] = true
                previousFlippedCardIndex = nil
                
                score += 30
            }
            else {      // Mismatched
                score -= 10
            }
        }
        
        flipCount += 1
    }
    
    public func changeTheme(label: String) {
        let newTheme: Array<String>? = GameTheme.getTheme(label: label)
        if newTheme == nil {
            return
        }
        currentTheme = newTheme
        reset()
    }
    public func changeTheme(index: Int) {
        currentTheme = GameTheme.getTheme(index: index)
        reset()
    }
    
    public func flipAll() {
        if !checkWin() {
            score -= 1000
        }
        for i in 0...15 {
            eachCardIsFlipped![i] = true
            eachCardIsChecked![i] = true
        }
        flipCount = 0
    }
    
    public func reset() {
        shuffle()
        previousFlippedCardIndex = nil
        flipCount = 0
        score = 0
    }
    
    public func getFlipCount() -> Int {
        return flipCount
    }
    public func getScore() -> Int {
        return score
    }
    public func getCardContent(index: Int) -> String {
        return eachCardContent![index]
    }
    public func isCardFlipped(index: Int) -> Bool {
        return eachCardIsFlipped![index]
    }
    public func isCardChecked(index: Int) -> Bool {
        return eachCardIsChecked![index]
    }
    
}
