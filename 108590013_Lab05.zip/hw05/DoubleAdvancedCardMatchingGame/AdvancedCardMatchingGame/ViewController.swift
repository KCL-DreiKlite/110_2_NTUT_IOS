//
//  ViewController.swift
//  AdvancedCardMatchingGame
//
//  Created by 郭建麟 on 2022/3/30.
//

import UIKit

class ViewController: UIViewController {
    
    let model: Model = Model()
    
    let FLIPPED_COLOR = #colorLiteral(red: 0.5098039216, green: 0.4352941176, blue: 0.4, alpha: 1)
    let UNFLIP_COLOR = #colorLiteral(red: 0.7764705882, green: 0.6078431373, blue: 0.4823529412, alpha: 1)
    let CHECKED_COLOR = #colorLiteral(red: 0.8039215803, green: 0.8039215803, blue: 0.8039215803, alpha: 1)
    
    @IBOutlet weak var labelFlipCount: UILabel!
    @IBOutlet weak var labelScore: UILabel!
    @IBOutlet var buttonCardsCollection: [UIButton]!
    @IBOutlet weak var popupbuttonThemeSelector: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        // Create menu
        popupbuttonThemeSelector.menu = UIMenu(children: [
            UIAction(title: "Theme : \(GameTheme.FLAG_LABEL)", handler: {
                action in
                self.model.changeTheme(label: GameTheme.FLAG_LABEL)
                self.updateView()
            }),
            UIAction(title: "Theme : \(GameTheme.ELECTRONIC_LABEL)", handler: {
                action in
                self.model.changeTheme(label: GameTheme.ELECTRONIC_LABEL)
                self.updateView()
            }),
            UIAction(title: "Theme : \(GameTheme.VEHICLE_LABEL)", handler: {
                action in
                self.model.changeTheme(label: GameTheme.VEHICLE_LABEL)
                self.updateView()
            }),
            UIAction(title: "Theme : \(GameTheme.FOOD_LABEL)", handler: {
                action in
                self.model.changeTheme(label: GameTheme.FOOD_LABEL)
                self.updateView()
            })
        ])
        
        // Select theme randomly
        let startupTheme: Int = Int.random(in: 0...3)
        
        (popupbuttonThemeSelector.menu?.children[startupTheme] as? UIAction)?.state = .on
        model.changeTheme(index: startupTheme)
        
        model.reset()
        updateView()
    }
    
    func findCardIndex(whichButton: UIButton) -> Int {
        var index: Int = 0
        for nextButton in buttonCardsCollection {
            if whichButton == nextButton {
                return index
            }
            index += 1
        }
        return -1
    }

    @IBAction func buttonCard_Clicked(_ sender: UIButton) {
        model.cardClicked(cardIndex: findCardIndex(whichButton: sender))
        updateView()
    }
    @IBAction func buttonFlipAll_Clicked(_ sender: UIButton) {
        model.flipAll()
        updateView()
    }
    @IBAction func buttonReset_Clicked(_ sender: UIButton) {
        model.reset()
        updateView()
    }
    
    func updateView() {
        for i in 0...15 {
            let curCard = buttonCardsCollection[i]
            let curCardContent = model.getCardContent(index: i)
            let curCardIsFlipped = model.isCardFlipped(index: i)
            let curCardIsChecked = model.isCardChecked(index: i)
            
            if curCardIsFlipped {
                curCard.setTitle(curCardContent, for: .normal)
                if curCardIsChecked {
                    curCard.backgroundColor = CHECKED_COLOR
                }
                else {
                    curCard.backgroundColor = FLIPPED_COLOR
                }
                
            }
            else {
                curCard.setTitle("", for: .normal)
                curCard.backgroundColor = UNFLIP_COLOR
            }
        }
        
        labelFlipCount.text = "Flips : \(model.getFlipCount())"
        labelScore.text = "Score : \(model.getScore())"
    }
    
}

