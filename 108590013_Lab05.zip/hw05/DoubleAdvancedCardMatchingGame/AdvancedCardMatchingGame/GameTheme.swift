//
//  GameTheme.swift
//  AdvancedCardMatchingGame
//
//  Created by 郭建麟 on 2022/4/16.
//

import Foundation

class GameTheme {
    
    public static let THEME_NATIONAL_FLAG: Array<String> = ["🇹🇼", "🇯🇵", "🇪🇸", "🇬🇧", "🇩🇪", "🇺🇸", "🇮🇱", "🇮🇹"]
    public static let THEME_ELECTRONIC: Array<String> = ["⌚️", "📱", "💻", "🖥", "🖨", "🖱", "⌨️", "📷"]
    public static let THEME_VEHICLE: Array<String> = ["🚗", "🚌", "🚕", "🏎", "🚓", "🚑", "🚛", "🚜"]
    public static let THEME_FOOD: Array<String> = ["🍜", "🌮", "🍕", "🍔", "🍙", "🍰", "🍩", "🍎"]
    
    public static let FLAG_LABEL: String = "National Flag"
    public static let ELECTRONIC_LABEL: String = "Electronic"
    public static let VEHICLE_LABEL: String = "Vehicle"
    public static let FOOD_LABEL: String = "Food"
    
    public static func getTheme(label: String) -> Array<String>? {
        switch label {
        case FLAG_LABEL:
            return THEME_NATIONAL_FLAG
        case ELECTRONIC_LABEL:
            return THEME_ELECTRONIC
        case VEHICLE_LABEL:
            return THEME_VEHICLE
        case FOOD_LABEL:
            return THEME_FOOD
        default:
            return nil
        }
    }
    
    public static func getTheme(index: Int) -> Array<String>? {
        switch index {
        case 0:
            return THEME_NATIONAL_FLAG
        case 1:
            return THEME_ELECTRONIC
        case 2:
            return THEME_VEHICLE
        case 3:
            return THEME_FOOD
        default:
            return nil
        }
    }
    
}
