//
//  ComputerSpecBroswerApp.swift
//  ComputerSpecBroswer
//
//  Created by 郭建麟 on 2022/5/16.
//

import SwiftUI

@main
struct ComputerSpecBroswerApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
