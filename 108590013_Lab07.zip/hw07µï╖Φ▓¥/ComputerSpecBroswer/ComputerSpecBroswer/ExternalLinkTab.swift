//
//  ExternalLinkTab.swift
//  ComputerSpecBroswer
//
//  Created by 郭建麟 on 2022/5/18.
//

import Foundation
import SwiftUI


struct ExternalLinkTab: View {
    let externalLinks: Array<ExternalLinkRow> = [
        ExternalLinkRow(url: "https://www.coolpc.com.tw/evaluate.php", imageName: "coolpc-logo"),
        ExternalLinkRow(url: "https://24h.pchome.com.tw/index/", imageName: "pchome24-logo")
    ]
        
    var body: some View {
        VStack {
            Text("External Link")
                .frame(maxWidth: .infinity, alignment: .center)
                .font(.largeTitle.bold())
            List {
                ForEach(externalLinks.indices) {index in
                    externalLinks[index]
                }
            }
        }
        .tabItem {
            VStack {
                Image(systemName: "arrowshape.turn.up.right")
                Text("External Link")
            }
        }
    }
}

struct ExternalLinkRow: View {
    let url: String
    let imageName: String
    
    var body: some View {
        Link(destination: URL(string: url)!) {
            Image(imageName)
                .resizable()
                .scaledToFit()
                .frame(maxWidth: .infinity, maxHeight: 100, alignment: .center)
        }
    }
}
