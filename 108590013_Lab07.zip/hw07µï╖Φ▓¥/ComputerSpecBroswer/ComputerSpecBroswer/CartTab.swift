//
//  SelectedSpecTab.swift
//  ComputerSpecBroswer
//
//  Created by 郭建麟 on 2022/5/18.
//

import Foundation
import SwiftUI


struct CartTab: View {
    @StateObject var model: Model
    
//    @State private var incartSpecs: Array<SpecInformation> = []
    
//    public mutating func addSpecToCart(_ newSpec: SpecInformation) {
//        if incartSpecs.contains(where: {spec in spec.name == newSpec.name}) {
//            return
//        }
//        incartSpecs.append(newSpec)
//    }
//    public mutating func clearCart() {
//        incartSpecs.removeAll()
//    }
    
//    public func updateIncartSpecs() {
//        incartSpecs.removeAll()
////        incartSpecs.append(contentsOf: model.getCart())
////        incartSpecs = model.getCart()
//        for eachSpec in model.getCart() {
//            incartSpecs.append(eachSpec)
//        }
//    }
    
//    init(model: Model) {
//        self.model = model
//
//        print(model.cart)
//    }
    
    var body: some View {
        NavigationView {
            if model.cart.isEmpty {
                Text("Nothing is in cart now")
                    .foregroundColor(Color.gray)
            }
            else {
                ScrollView(.horizontal) {
                    HStack {
                        ForEach(model.cart, id: \.name) {spec in
                            NavigationLink {
                                SpecDetail(mySpec: spec, model: model)
    //                                .frame(maxWidth: 20, maxHeight: 20)
                            } label: {
                                SpecPreviewItem(content: spec)
                                    .scaledToFit()
                                    .frame(maxWidth: 500, maxHeight: 500)
                            }
                        }
                    }
                }
                .navigationTitle("Cart")
                .toolbar {
                    Button {
                        model.clearCart()
    //                    for spec in model.cart {
    //                        print(spec.name)
    //                    }
                    } label: {
                        VStack {
                            Image(systemName: "trash")
                            Text("Clear All")
                                .font(.caption)
                        }
                    }

                }
            }
        }
        .tabItem({
            VStack {
                Image(systemName: "cart")
                Text("Cart")
            }
        })
    }
}
