//
//  Model.swift
//  ComputerSpecBroswer
//
//  Created by 郭建麟 on 2022/5/18.
//

import Foundation

class Model : ObservableObject {
    
//    public var specAdder: ((SpecInformation) -> Void)!
//    public var specClearer: (() -> Void)!
//
//    public func addSpecToCart(_ newSpec: SpecInformation) {
//        if specAdder != nil {
//            specAdder(newSpec)
//        }
//    }
//
//    public func clearCart() {
//        if specClearer != nil {
//            specClearer()
//        }
//    }
    
//    private var cartNotifier: (() -> Void)!
    
    init() {
        print("Hello fellows, I'm model!")
    }
    
    @Published var cart: Array<SpecInformation> = [] {
        didSet {
            print("oh shit i just be modified!")
            for spec in cart {
                print(spec.name)
            }
        }
    }
    
    public func addSpecToCart(_ newSpec: SpecInformation) {
        if cart.contains(where: {spec in spec.name == newSpec.name}) {
            return
        }
        cart.append(newSpec)

//        notifyCart()
    }
    public func clearCart() {
        cart.removeAll()

//        notifyCart()
    }
    
//    private func notifyCart() {
//        if cartNotifier != nil {
//            cartNotifier()
//        }
//    }
    
//    public func setCartNotifier(notifier: @escaping () -> Void) {
//        cartNotifier = notifier
//    }
//
//    public func getCart() -> Array<SpecInformation> {
//        return cart
//    }
}
