//
//  SpecCategory.swift
//  ComputerSpecBroswer
//
//  Created by 郭建麟 on 2022/5/16.
//

import Foundation
import SwiftUI

struct SpecCategory: View {
    let title: String
    let content: Array<SpecInformation>
    let columnCount: Int
    var model: Model
    
    var columns: Array<GridItem> {
        Array(repeating: GridItem(), count: columnCount)
    }
//    let bruh = SpecDatabase.generateIntelCPUs()
    
    var body: some View {
//        NavigationView {
            ScrollView {
                LazyVGrid(columns: columns) {
                    ForEach(content.indices) {specIndex in
                        NavigationLink {
                            SpecDetail(mySpec: content[specIndex], model: model)
                        } label: {
                            SpecPreviewItem(content: content[specIndex])
                        }
                    }
                }
            }
            .navigationTitle(title)
//            .navigationBarTitleDisplayMode()
//        }
        
    }
}
