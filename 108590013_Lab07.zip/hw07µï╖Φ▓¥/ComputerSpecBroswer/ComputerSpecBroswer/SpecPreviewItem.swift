//
//  SpecPreviewItem.swift
//  ComputerSpecBroswer
//
//  Created by 郭建麟 on 2022/5/18.
//

import Foundation
import SwiftUI

struct SpecPreviewItem: View {
    let content: SpecInformation
    
    var body: some View {
        VStack {
            Image(content.imageName)
                .resizable()
                .scaledToFit()
            Text(content.name)
                .frame(maxWidth: .infinity)
                .font(.title2.bold())
                .foregroundColor(Color.black)
        }
    }
}
