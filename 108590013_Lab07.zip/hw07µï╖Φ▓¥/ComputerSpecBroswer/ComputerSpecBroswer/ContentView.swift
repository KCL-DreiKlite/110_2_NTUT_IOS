//
//  ContentView.swift
//  ComputerSpecBroswer
//
//  Created by 郭建麟 on 2022/5/16.
//

import SwiftUI

struct ContentView: View {
    @StateObject var model: Model = Model()
    
//    let specNavigationTab: SpecNavigationTab
//    var cartTab: CartTab
    
//    init() {
//        specNavigationTab = SpecNavigationTab(model: model)
//        cartTab = CartTab(model: model)
//
////        cartTab.addSpecToCart(SpecDatabase.cpu_intel_12700k)
//
////        model.setCartNotifier(notifier: cartTab.updateIncartSpecs)
////        model.specAdder = cartTab.addSpecToCart(_:)
////        model.specClearer = cartTab.clearCart
//    }
    
    var body: some View {
//        SpecNavigationTab()
        TabView {
//            specNavigationTab
//            cartTab
            SpecNavigationTab(model: model)
            CartTab(model: model)
            ExternalLinkTab()
        }
//        TabView {
//            SpecDetail(mySpec: SpecDatabase.cpu_intel_12700k)
//                .tabItem({
//                    Text("hi")
//                })
//            SpecDetail(mySpec: SpecDatabase.cpu_intel_12600k)
//                .tabItem({
//                    Text("bye")
//                })
//        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
