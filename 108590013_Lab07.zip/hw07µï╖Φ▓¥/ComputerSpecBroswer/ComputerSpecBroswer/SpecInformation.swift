//
//  SpecInformation.swift
//  ComputerSpecBroswer
//
//  Created by 郭建麟 on 2022/5/16.
//

import Foundation

class SpecInformation {
    public enum Category {
        case CPU
        case RAM
        case MOTHERBOARD
        case GPU
        case CASE
        case PSU
        case RADIATOR
    }
    
    public let name: String
    public let type: Category
    public let info: String
    
    public let imageName: String
    
    init(name: String, type: Category, info: String, imageName: String) {
        self.name = name
        self.type = type
        self.info = info
        self.imageName = imageName
    }
}
