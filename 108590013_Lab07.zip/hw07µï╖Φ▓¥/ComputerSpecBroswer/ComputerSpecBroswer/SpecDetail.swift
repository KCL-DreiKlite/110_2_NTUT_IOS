//
//  SpecDetail.swift
//  ComputerSpecBroswer
//
//  Created by 郭建麟 on 2022/5/16.
//

import Foundation
import SwiftUI

struct SpecDetail: View {
    let mySpec: SpecInformation
    var model: Model
    
    var body: some View {
        ScrollView {
            VStack {
                Image(mySpec.imageName)
                    .resizable()
                    .scaledToFit()
//                    .frame(maxWidth: 200, maxHeight: 200)
                Text(mySpec.name)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .font(.title2.bold())
                Text("")
                    .frame(maxWidth: .infinity)
                Text(mySpec.info)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .font(.body.bold())
                Button {
                    model.addSpecToCart(mySpec)
//                    model.cart.append(mySpec)
//                    print("Oops! This feature is not be implemented yet")
                } label: {
                    Text("Add to cart")
                        .frame(minWidth: 40, maxWidth: .infinity, minHeight: 40, maxHeight: 40)
                        .background(Color.blue)
                        .foregroundColor(Color.white)
                        .cornerRadius(15)
                }
            }
        }
        .padding(10)
        .navigationTitle("Information")
    }
}
