//
//  SpecNavigationTab.swift
//  ComputerSpecBroswer
//
//  Created by 郭建麟 on 2022/5/16.
//

import Foundation
import SwiftUI

struct SpecNavigationTab: View {
    var model: Model
    
    let rows: Array<SpecNavigationRow> = [
        SpecNavigationRow(previewImage: SpecDatabase.cpu_intel_12700k.imageName, content: SpecDatabase.generateCPUs(), title: "CPU"),
        SpecNavigationRow(previewImage: SpecDatabase.gpu_nvidia_3080ti.imageName, content: SpecDatabase.generateGPUs(), title: "GPU")
    ]
    
    var body: some View {
        NavigationView {
            List {
                ForEach(rows.indices) {rowIndex in
                    NavigationLink {
                        let row = rows[rowIndex]
                        SpecCategory(title: row.title, content: row.content, columnCount: 2, model: model)
                    } label: {
                        rows[rowIndex]
                    }
                }
            }
            .navigationTitle("Browse")
        }
        .navigationViewStyle(.stack)
        .tabItem({
            VStack {
                Image(systemName: "safari")
                Text("Spec Navigation")
            }
        })
    }
}

struct SpecNavigationRow: View {
    let previewImage: String
    let content: Array<SpecInformation>
    let title: String
    
    
    var body: some View {
        HStack {
            Image(previewImage)
                .resizable()
                .scaledToFit()
                .frame(minWidth: 100, maxWidth: 100, minHeight: 100, maxHeight: 100)
            Text(title)
                .frame(maxWidth: .infinity, alignment: .leading)
                .font(.title.bold())
                .padding()
        }
    }
}
