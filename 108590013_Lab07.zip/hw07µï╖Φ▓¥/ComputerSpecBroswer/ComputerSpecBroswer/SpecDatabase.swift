//
//  SpecDatabase.swift
//  ComputerSpecBroswer
//
//  Created by 郭建麟 on 2022/5/16.
//

import Foundation

class SpecDatabase {
    public static let cpu_intel_12700k = SpecInformation(name: "Intel 12700k", type: .CPU, info: "Socket: 1700\nBoost: 3.6 - 5.0 GHz\nCore / Thread: 12 / 20\nTDP: 125W", imageName: "12700k")
    public static let cpu_intel_12600k = SpecInformation(name: "Intel 12600k", type: .CPU, info: "Socket: 1700\nBoost: 3.6 - 4.9 GHz\nCore / Thread: 10 / 16\nTDP: 125W", imageName: "12600k")
    public static let cpu_inetl_12400 = SpecInformation(name: "Intel 12400", type: .CPU, info: "Socket: 1700\nBoost: 2.5 - 4.4 GHz\nCore/ Thread: 6 / 12\nTDP: 65W", imageName: "12400")
    public static let cpu_amd_5600x = SpecInformation(name: "AMD R5 5600x", type: .CPU, info: "Socket: AM4\nBoost: 3.7 - 4.6 GHz\nCore / Thread: 6 / 12\nTDP: 65W", imageName: "r5_5600x")
    public static let cpu_amd_5800x = SpecInformation(name: "AMD R7 5800x", type: .CPU, info: "Socket: AM4\nBppst: 3.8 - 4.7 GHz\nCore / Thread: 8 / 16\nTDP:105W", imageName: "r7_5800x")
    
    public static let gpu_nvidia_3090 = SpecInformation(name: "RTX 3090", type: .GPU, info: "Nvidia Geforce RTX 3090 Founder Edition\nCUDA: 10496\nBoost: 1.2 GHz\nVRAM: 24 GB GDDR6X", imageName: "rtx3090")
    public static let gpu_nvidia_3080ti = SpecInformation(name: "RTX 3080 Ti", type: .GPU, info: "Nvidia Geforce RTX 3080 Ti Founder Edition\nCUDA: 10240\nBoost: 1.67 GHz\nVRAM: 12 GB GDDR6X", imageName: "rtx3080ti")
    public static let gpu_nvidia_3070 = SpecInformation(name: "RTX 3070", type: .GPU, info: "Nvidia Geforce RTX 3070 Founder Edition\nCUDA: 5888\nBoost: 1.73 GHz\nVRAM: 8 GB GDDR6", imageName: "rtx3070")

    
    
    public static func generateIntelCPUs() -> Array<SpecInformation> {
        return [
            cpu_intel_12700k,
            cpu_intel_12600k,
            cpu_inetl_12400
        ]
    }
    public static func generateAMDCPUs() -> Array<SpecInformation> {
        return [
            cpu_amd_5800x,
            cpu_amd_5600x
        ]
    }
    public static func generateCPUs() -> Array<SpecInformation> {
        return [
            cpu_intel_12700k,
            cpu_intel_12600k,
            cpu_inetl_12400,
            cpu_amd_5800x,
            cpu_amd_5600x
        ]
    }
    
    public static func generateGPUs() -> Array<SpecInformation> {
        return [
            gpu_nvidia_3090,
            gpu_nvidia_3080ti,
            gpu_nvidia_3070
        ]
    }
}
