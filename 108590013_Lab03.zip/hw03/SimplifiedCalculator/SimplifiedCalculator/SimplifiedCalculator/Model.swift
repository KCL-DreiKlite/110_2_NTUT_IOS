//
//  Model.swift
//  SimplifiedCalculator
//
//  Created by 郭建麟 on 2022/3/28.
//

import Foundation

class Model {
    let OPERATION_PLUS: Int = 0
    let OPERATION_MINUS: Int = 1
    let OPERATION_MULTIPLY: Int = 2
    let OPERATION_DIVIDE: Int = 3
    let OPERATION_EQUAL: Int = 4
    
    var currentFormula: String? = " "
    var currentNumber: Int = 0
    
    var currentResult: Int = 0
    
    var nextOperation: Int?
    
    var isCalculated: Bool = false
        
    func inputNumber(input: Int) {
        if isCalculated {
            currentFormula = " "
            currentNumber = 0
            currentResult = 0
            isCalculated = false
        }
        currentNumber = currentNumber * 10 + input
    }
    
    func calculate() {
        var operationChar: String = ""
        switch nextOperation {
        case OPERATION_PLUS:
            currentResult += currentNumber
            operationChar = "+"
        case OPERATION_MINUS:
            currentResult -= currentNumber
            operationChar = "-"
        case OPERATION_MULTIPLY:
            currentResult *= currentNumber
            operationChar = "x"
        case OPERATION_DIVIDE:
            currentResult /= currentNumber
            operationChar = "/"
        default:
            currentResult = currentNumber
            operationChar = ""
        }
        
        if isCalculated {
            currentFormula = " "
            isCalculated = false
        }
        
        currentFormula! += operationChar + "\(currentNumber)"
        currentNumber = 0
    }
    
    func operateEqual() {
        calculate()
        nextOperation = nil
        currentFormula! += "="
        currentNumber = currentResult
        isCalculated = true
    }
    
    func operatePlus() {
        calculate()
        nextOperation = OPERATION_PLUS
    }
    func operateMinus() {
        calculate()
        nextOperation = OPERATION_MINUS
    }
    func operateMultiply() {
        calculate()
        nextOperation = OPERATION_MULTIPLY
    }
    func operateDivide() {
        calculate()
        nextOperation = OPERATION_DIVIDE
    }
    
    func clearResult() {
        currentFormula = " "
        currentNumber = 0
        currentResult = 0
        nextOperation = nil
        isCalculated = false
    }
}
