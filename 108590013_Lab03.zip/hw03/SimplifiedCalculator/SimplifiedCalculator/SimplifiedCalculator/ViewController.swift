//
//  ViewController.swift
//  SimplifiedCalculator
//
//  Created by 郭建麟 on 2022/3/21.
//

import UIKit

class ViewController: UIViewController {
    
    let model: Model = Model()
    
    @IBOutlet weak var labelFormula: UILabel!
    @IBOutlet weak var labelNumber: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func buttonClearResult_Clicked(_ sender: UIButton) {
        model.clearResult()
        updateView()
    }
    
    @IBAction func buttonDivide_Clicked(_ sender: UIButton) {
        model.operateDivide()
        updateView()
    }
    @IBAction func buttonMultiply_Clicked(_ sender: UIButton) {
        model.operateMultiply()
        updateView()
    }
    @IBAction func buttonMinus_Clicked(_ sender: UIButton) {
        model.operateMinus()
        updateView()
    }
    @IBAction func buttonPlus_Clicked(_ sender: UIButton) {
        model.operatePlus()
        updateView()
    }
    @IBAction func buttonEqual_Clicked(_ sender: UIButton) {
        model.operateEqual()
        updateView()
    }
    
    @IBAction func buttonNumberPad_Clicked(_ sender: UIButton) {
        let number: Int = Int((sender.titleLabel?.text)!) ?? 0
        model.inputNumber(input: number)
        updateView()
    }
    
    func updateView() {
        labelFormula.text = model.currentFormula
        labelNumber.text = String(model.currentNumber)
    }
    
}

