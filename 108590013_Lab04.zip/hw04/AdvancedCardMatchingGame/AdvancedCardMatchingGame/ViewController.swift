//
//  ViewController.swift
//  AdvancedCardMatchingGame
//
//  Created by 郭建麟 on 2022/3/30.
//

import UIKit

class ViewController: UIViewController {
    
    let model: Model = Model()
    
    let FLIPPED_COLOR = #colorLiteral(red: 0.5098039216, green: 0.4352941176, blue: 0.4, alpha: 1)
    let UNFLIP_COLOR = #colorLiteral(red: 0.7764705882, green: 0.6078431373, blue: 0.4823529412, alpha: 1)
    let CHECKED_COLOR = #colorLiteral(red: 0.8039215803, green: 0.8039215803, blue: 0.8039215803, alpha: 1)
    
    @IBOutlet weak var labelFlipCount: UILabel!
    @IBOutlet var buttonCardsCollection: [UIButton]!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        model.reset()
        updateView()
    }
    
    func findCardIndex(whichButton: UIButton) -> Int {
        var index: Int = 0
        for nextButton in buttonCardsCollection {
            if whichButton == nextButton {
                return index
            }
            index += 1
        }
        return -1
    }

    @IBAction func buttonCard_Clicked(_ sender: UIButton) {
        model.cardClicked(cardIndex: findCardIndex(whichButton: sender))
        updateView()
    }
    @IBAction func buttonFlipAll_Clicked(_ sender: UIButton) {
        model.flipAll()
        updateView()
    }
    @IBAction func buttonReset_Clicked(_ sender: UIButton) {
        model.reset()
        updateView()
    }
    
    func updateView() {
        for i in 0...15 {
            let curCard = buttonCardsCollection[i]
            let curCardContent = model.eachCardContent![i]
            let curCardIsFlipped = model.eachCardIsFlipped![i]
            let curCardIsChecked = model.eachCardIsChecked![i]
            
            if curCardIsFlipped {
                curCard.setTitle(curCardContent, for: .normal)
                if curCardIsChecked {
                    curCard.backgroundColor = CHECKED_COLOR
                }
                else {
                    curCard.backgroundColor = FLIPPED_COLOR
                }
                
            }
            else {
                curCard.setTitle("", for: .normal)
                curCard.backgroundColor = UNFLIP_COLOR
            }
        }
        
        labelFlipCount.text = "Flips : \(model.flipCount)"
    }
    
}

